/* 
 * File:   Block.h
 * Author: pancho
 *
 * Created on 27 July 2011, 19:19
 */
#ifndef BLOCK_H
#define	BLOCK_H

#include <vector>
#include <iostream>
#include "AttachableElement.h"

using namespace std;

class Block:public AttachableElement {
public:
    Block();
    Block(float mass, Vector2D position, Vector2D speed);
    void attachSpring(Spring spring);
    virtual void detachSpring(Spring spring);
    Vector2D getPosition();
    void setInitialState(float g);
    void updateState();
    string getDescription();
    string getState();

private:
    static int id;
    int myid;
    float mass;
    Vector2D pos;
    Vector2D speed_t;
    Vector2D speed_tPlusDelta;
    Vector2D accel_t;
    Vector2D accel_tMinusDelta;
    Vector2D getNetForce(float g);
    vector<Spring> springs;
};
#endif	/* BLOCK_H */

