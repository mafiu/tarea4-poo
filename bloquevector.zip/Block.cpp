/* 
 * File:   Block.cpp
 * Author: pancho
 * 
 * Created on 27 July 2011, 19:19
 */

#include "Block.h"
using namespace std;

Block::Block(float m,Vector2D position, Vector2D speed){
    
    this->mass = m;
    this->pos = position;
    this->speed_t = speed;

}

/* Obtener informacion del objeto en formato String */
Vector2D Block::getPosition(void) {
    return this->pos;
}

string Block::getDescription() {
    return "Hola";
    //    return "Block #" + getId() + ": x,y";
}

string Block::getState() {
    return "Hola";
    //    return getPosition().getX() + "," + getPosition().getY() + "";
}

/* Asociar a Resortes*/

void Block::attachSpring(Spring spring) {

}

void Block::detachSpring(Spring spring) {

}

/* Calcular Fuerzas y Estados */

//Vector2D Block::getNetForce(float g) {
//
//}

void Block::setInitialState(float g) {

}

void Block::updateState() {

}

