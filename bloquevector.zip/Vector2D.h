/* 
 * File:   Vector2D.h
 * Author: pancho
 *
 * Created on 27 June 2011, 22:46
 */

#ifndef VECTOR2D_H
#define	VECTOR2D_H

#include <math.h>

class Vector2D {
public:
    
    Vector2D();
    Vector2D(double pos_x, double pos_y);

    double get_PosX();
    double get_PosY();
    void set_PosX(double pos_x);
    void set_PosY(double pos_y);
    void suma(Vector2D v2);
    void resta(Vector2D v2);

private:
    double x, y;
};

#endif	/* VECTOR2D_H */

