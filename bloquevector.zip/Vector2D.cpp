/* 
 * File:   Vector2D.cpp
 * Author: pancho
 * 
 * Created on 27 June 2011, 22:46
 */

#include "Vector2D.h"

Vector2D::Vector2D() {}

Vector2D::Vector2D(double pos_x, double pos_y){
    this->x = pos_x;
    this->y = pos_y;
}

void Vector2D::set_PosX(double pos_x){
    this->x = pos_x;
}

void Vector2D::set_PosY(double pos_y){
    this->y = pos_y;
}

double Vector2D::get_PosX(){
    return this->x;
}

double Vector2D::get_PosY(){
    return this->y;
}

void Vector2D::suma(Vector2D v2){
    this->x = get_PosX() + v2.get_PosX();
    this->y = get_PosY() + v2.get_PosY();
}

void Vector2D::resta(Vector2D v2){
    this->x = get_PosX() - v2.get_PosX();
    this->y = get_PosY() - v2.get_PosY();
}


